<?php

return array(

	/*
	|--------------------------------------------------------------------------
	| Your Infusionsoft OAuth2 Credentials
	|--------------------------------------------------------------------------
	*/

	'clientId' => env('INFUSIONSOFT_CLIENT_ID'),

	'clientSecret' => env('INFUSIONSOFT_SECRET'),

	'redirectUri' => env('INFUSIONSOFT_REDIRECT_URL'),

);
