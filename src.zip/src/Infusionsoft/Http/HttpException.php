<?php

namespace Infusionsoft\Http;

use Infusionsoft\InfusionsoftException;

class HttpException extends InfusionsoftException {

}